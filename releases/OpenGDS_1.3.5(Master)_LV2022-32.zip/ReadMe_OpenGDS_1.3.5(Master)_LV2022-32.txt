Welcome to OpenGDS
This is the release: 1.3.5(Master), build for: LV2022-32
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.3.5(Master)_LV2022-32.vi).