Welcome to OpenGDS
This is the release: 1.2.85(LV2020), build for: LV2020-64
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.2.85(LV2020)_LV2020-64.vi).