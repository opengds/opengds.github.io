Welcome to OpenGDS
This is the release: 1.3.7(Master), build for: LV2020-64
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.3.7(Master)_LV2020-64.vi).