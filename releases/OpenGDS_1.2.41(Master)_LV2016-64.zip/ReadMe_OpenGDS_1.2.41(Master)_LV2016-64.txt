Welcome to OpenGDS
This is the release: 1.2.41(Master), build for: LV2016-64
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.2.41(Master)_LV2016-64.vi).