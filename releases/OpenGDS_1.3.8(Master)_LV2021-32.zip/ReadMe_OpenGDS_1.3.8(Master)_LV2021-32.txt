Welcome to OpenGDS
This is the release: 1.3.8(Master), build for: LV2021-32
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.3.8(Master)_LV2021-32.vi).