Welcome to OpenGDS
This is the release: 1.1.23(Master), build for: LV2012-32
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.1.23(Master)_LV2012-32.vi).