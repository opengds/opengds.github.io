Welcome to OpenGDS
This is the release: 1.2.72(LV2020), build for: LV2021-32
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.2.72(LV2020)_LV2021-32.vi).