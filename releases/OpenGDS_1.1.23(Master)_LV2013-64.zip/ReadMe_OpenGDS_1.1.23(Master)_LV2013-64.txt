Welcome to OpenGDS
This is the release: 1.1.23(Master), build for: LV2013-64
To install this version use either, VIPM or the installer VI (Installer_OpenGDS_1.1.23(Master)_LV2013-64.vi).